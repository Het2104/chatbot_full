"""Online RAG processing modules"""
