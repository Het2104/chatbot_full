"""Offline RAG processing modules"""
